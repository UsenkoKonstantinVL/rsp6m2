﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace rsp6m2.Controls
{
    public partial class Littlebutton : UserControl
    {
        public Littlebutton()
        {
            InitializeComponent();
        }
    }
}
