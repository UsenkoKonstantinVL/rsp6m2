﻿using System;
using System.Collections.Generic;
using System.Text;

namespace rsp6m2.Controls
{
    interface IHighlightControl
    {
        void Highlight();

        void UnHighlight();
    }
}
